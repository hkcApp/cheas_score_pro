import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/game.dart';

class StorageService {
  StorageService._();

  static final StorageService instance = StorageService._();

  static const String _savedGameKey =
      'cheas_score_pro_current_game';

  Future<void> saveGame(Game game) async {
    final prefs =
        await SharedPreferences.getInstance();

    final json =
        jsonEncode(
          game.toJson(),
        );

    debugPrint("====== SAVING GAME ======");
    for (final p in game.players) {
      debugPrint(
        "${p.name}   Wind:${p.wind}   Score:${p.score}",
      );
    }

    await prefs.setString(
      _savedGameKey,
      json,
    );
  }

  Future<Game?> loadGame() async {
    final prefs =
        await SharedPreferences.getInstance();

    final data =
        prefs.getString(
          _savedGameKey,
        );

    if (data == null) {
      return null;
    }

    final game = Game.fromJson(
      jsonDecode(data),
    );

    debugPrint("====== LOADED GAME ======");
    for (final p in game.players) {
      debugPrint(
        "${p.name}   Wind:${p.wind}   Score:${p.score}",
      );
    }

    return game;
  }

  Future<void> deleteGame() async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.remove(
      _savedGameKey,
    );
  }

  Future<bool> hasSavedGame() async {
    final prefs =
        await SharedPreferences.getInstance();

    return prefs.containsKey(
      _savedGameKey,
    );
  }
}