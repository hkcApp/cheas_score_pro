import 'package:flutter/foundation.dart';

import '../models/game.dart';
import 'storage_service.dart';

class GameService {
  GameService._();

  static final GameService instance = GameService._();

  Game? _currentGame;

  Game? get currentGame => _currentGame;

  bool get hasActiveGame => _currentGame != null;

  Future<void> startNewGame({
    required List<String> playerNames,
  }) async {
    debugPrint("========== START NEW GAME ==========");

    // Preserve existing player names if a game is already loaded.
    List<String> names = playerNames;

    if (_currentGame != null) {
      names = _currentGame!.players
          .map((p) => p.name)
          .toList();
    }

    debugPrint("Names being used:");
    for (final n in names) {
      debugPrint(n);
    }

    // Remove the previous saved game only.
    await StorageService.instance.deleteGame();

    // Create a brand new game.
    final game = Game();

    // Restore player names.
    game.setPlayerNames(names);

    _currentGame = game;

    await saveCurrentGame();
  }

  Future<void> saveCurrentGame() async {
    debugPrint("========== saveCurrentGame() ==========");

    final game = _currentGame;

    if (game == null) {
      debugPrint("Current game is NULL");
      return;
    }

    debugPrint("Players before saving:");

    for (final p in game.players) {
      debugPrint(
        "${p.name}   Wind:${p.wind}   Score:${p.score}",
      );
    }

    await StorageService.instance.saveGame(game);

    debugPrint("Game saved.");
  }

  Future<bool> loadSavedGame() async {
    debugPrint("========== loadSavedGame() ==========");

    final game = await StorageService.instance.loadGame();

    if (game == null) {
      debugPrint("No saved game found.");
      return false;
    }

    _currentGame = game;

    debugPrint("Loaded players:");

    for (final p in game.players) {
      debugPrint(
        "${p.name}   Wind:${p.wind}   Score:${p.score}",
      );
    }

    return true;
  }

  Future<void> deleteSavedGame() async {
    debugPrint("========== deleteSavedGame() ==========");

    await StorageService.instance.deleteGame();

    _currentGame = null;
  }

  void endGame() {
    _currentGame = null;
  }

  void resetCurrentGame() {
    _currentGame?.resetGame();
    saveCurrentGame();
  }

  void nextRound() {
    _currentGame?.nextRound();
    saveCurrentGame();
  }

  Game requireCurrentGame() {
    final game = _currentGame;

    if (game == null) {
      throw Exception('No active game.');
    }

    return game;
  }
}